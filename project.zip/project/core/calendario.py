import datetime
import os.path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/calendar"]

def obtener_servicio():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
    else:
        raise Exception("No se encontró token.json. Ejecuta la autenticación manualmente primero.")
    return build("calendar", "v3", credentials=creds)

def listar_eventos(max_results=10):
    servicio = obtener_servicio()
    now = datetime.datetime.utcnow().isoformat() + "Z"
    calendar_id = '368f8a72ad09d483503fdaebb646979976b1ea4d077c84b0c0305c9e5f50b799@group.calendar.google.com'
    eventos = (
        servicio.events()
        .list(calendarId=calendar_id, timeMin=now, maxResults=max_results, singleEvents=True, orderBy="startTime")
        .execute()
        .get("items", [])
    )
    return eventos

def crear_evento(title, descripcion, start, end):
    servicio = obtener_servicio()
    evento = {
        "summary": title,
        "description": descripcion,
        "start": {"dateTime": start, "timeZone": "America/Bogota"},
        "end": {"dateTime": end, "timeZone": "America/Bogota"},
    }
    evento_creado = servicio.events().insert(calendarId="primary", body=evento).execute()
    return evento_creado.get("htmlLink")