document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('calendario-js');
    if (calendarEl && window.FullCalendar) {
        const calendar = new window.FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek'
            },
            locale: 'es',
            height: 350,
            events: window.eventos,
            eventContent: function () {
                return { html: '<div class="punto-evento"></div>' };
            },
            eventClick: function(info) {
                alert('Evento: ' + info.event.title);
                // Aquí podrías abrir un modal si lo prefieres
            }
        });
        calendar.render();
    } else {
        console.warn("Elemento calendario-js o FullCalendar no cargado correctamente.");
    }
});
