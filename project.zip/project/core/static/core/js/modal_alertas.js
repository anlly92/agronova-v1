function abrirModalAlertas() {
        document.getElementById('modal-alertas').style.display = 'block';
    }

    function cerrarModalAlertas() {
        document.getElementById('modal-alertas').style.display = 'none';
    }

    // Cerrar el modal al hacer clic fuera del contenido
    