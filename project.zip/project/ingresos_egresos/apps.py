from django.apps import AppConfig


class IngresosEgresosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ingresos_egresos'
